---
strategy_id: orb-momentum-scalp
name: "Opening Range Breakout Momentum Scalp"
instrument: SPY
structure: single-leg
legs: [long_call OR long_put]
dte_range: [0, 1]
regime: negative_gamma / trending
complexity: low
direction: directional
edge_type: convexity (asymmetric payoff)
primary_session_window: "09:35–12:00 ET"
status: thesis_v1
---

# Strategy 01 — Opening Range Breakout (ORB) Momentum Scalp

> **Disclaimer:** This is a synthesis of publicly available trading research and community
> practice for use as a reference module in a trading tool. It is not financial advice and
> carries no guarantee of profit. 0DTE directional buying is a high-variance, low-win-rate
> approach where the *majority* of individual trades lose; the math only works if stops and
> position sizing are enforced mechanically. Treat capital risked as capital you can lose.

## 1. Thesis (the "why")

The first few minutes of the session compress overnight order flow, gap reactions, and
institutional positioning into a tight price range. When price breaks that range with
conviction, it tends to continue in the breakout direction long enough for an at-the-money
0DTE option to expand violently — because **gamma on same-day options is enormous**. A $1–2
SPY move after a clean breakout can double an ATM contract's value, while the maximum loss is
capped at the premium paid. That asymmetry — option can +100% on a moderate move, but you cut
it at −50% — is the entire edge. You lose more often than you win, but winners are ~2× losers.

This is **not** a high-win-rate strategy. Backtested mechanical versions land around a **~42%
win rate** with a **~2:1 winner/loser size ratio** — a classic trend-following profile. It
only survives because the stop is honored every single time.

## 2. When to deploy (regime filter)

| Condition | Deploy? | Reason |
|---|---|---|
| Net **negative** gamma (price below zero-gamma flip) | ✅ Best | Dealer hedging amplifies moves → breakouts run |
| Net **positive** gamma (price above flip, pinning regime) | ⚠️ Avoid / size down | Dealers fade moves → breakouts get sold back into the range |
| Scheduled catalyst at/after open (CPI, FOMC, NFP) | ✅ Strong | Real fuel for a directional move |
| Low-volatility, range-bound tape (VIX compressed, no catalyst) | ❌ Skip | Most false breakouts happen here |

The single most important external read: **gamma regime**. Negative gamma = momentum tape =
this strategy's home turf. Positive gamma = mean-reversion tape = use Strategy 03 instead.

## 3. Signals & indicators (inputs the portal must compute)

- **Opening Range (OR):** high and low of the **first 5 minutes** (09:30–09:35 ET). Backtests
  found the 5-min range outperformed 15/30/60-min ranges (earlier entry → more time for the
  position to work), at the cost of more false breakouts that the filters below screen out.
- **Minimum range width filter:** OR width must be ≥ **0.20%** of SPY price. Narrower ranges
  produce too many low-conviction whipsaws — skip the day.
- **VWAP:** breakout should be on the correct side of session VWAP (long above, short below).
- **9 / 21 EMA:** the two fast EMAs should agree with breakout direction (9 above 21 for longs).
- **NYSE TICK:** confirmation threshold **> +600** for call entries, **< −600** for puts.
- **Volume spike:** breakout candle volume should exceed the prior N-bar average (institutional
  participation, not a drift).

## 4. Entry rules (mechanical)

```
LONG CALL  when: SPY breaks ABOVE OR_high
              AND price > VWAP
              AND EMA9 > EMA21
              AND TICK > +600
              AND OR_width >= 0.20%
              AND time < 12:00 ET

LONG PUT   when: SPY breaks BELOW OR_low
              AND price < VWAP
              AND EMA9 < EMA21
              AND TICK < -600
              AND OR_width >= 0.20%
              AND time < 12:00 ET
```

- **Strike:** at-the-money (ATM). Pick the nearest strike to spot for max gamma + tightest
  bid/ask + highest volume. (e.g. SPY at $602.40 → trade the 602 strike.)
- **No new entries after 12:00 ET.** Afternoon breakouts have too little runway before theta
  and the close erode the position.

## 5. Position construction & sizing

- **Fixed dollar risk per trade** — size by contract price, not contract count. Target ~**1–2%
  of account** at risk per trade.
  - Example: $500 risk budget, ATM call costs $1.25 → buy 4 contracts ($500/$125).
  - Same budget, ATM call costs $2.50 → buy 2 contracts.
  - This holds dollar risk constant regardless of where SPY trades or how juiced premiums are.
- **0DTE is the default.** Use **1DTE** when you want slightly less gamma whipsaw and a touch
  more time cushion (e.g. late-week entries, or to ride a move overnight on a strong trend day).

## 6. Exit rules

| Exit | Trigger | Action |
|---|---|---|
| **Profit target** | Option price = **+100%** of entry (doubles) | Close full position |
| **Stop loss** | Option price = **−50%** of entry | Close full position, no exceptions |
| **Time stop** | **15:30 ET** reached with neither hit | Close at market |

Optional refinement: scale out half at +60–70% and trail the remainder to the 9 EMA on the
1-min chart. Adds complexity; the flat +100% / −50% / time-stop version is the cleanest to
automate and backtest first.

## 7. Failure modes (when this bleeds you)

- **Chop / inside days:** false breakout, snap back through the range, −50% stop. The 0.20%
  width filter + TICK filter exist to cut these; honor them.
- **Positive-gamma pinning days:** breakouts get sold; you'll get chopped to death. Check
  regime first.
- **Late entries:** anything after midday fights theta and the close. Don't.
- **Stop drift:** the strategy's entire edge is the −50% stop. Widening it once turns a
  managed loser into an account event.

## 8. Data inputs required (for the build)

- 1-min (or 30-sec) SPY OHLCV for OR construction + breakout detection
- Session VWAP
- 9 / 21 EMA on the SPY chart
- NYSE TICK feed (`$TICK` / `USI:TICK` / `NYSE:TICK` depending on data vendor)
- Live 0DTE/1DTE SPY option chain (ATM bid/ask, volume) for fills + P&L
- Net gamma / zero-gamma flip level (regime gate) — see shared GEX data note in Strategy 03

## 9. One-line summary

Buy the ATM 0DTE call (or put) on a confirmed 5-minute opening-range break in the direction of
VWAP/EMA/TICK on a negative-gamma day; target a double, stop at half, flat by 3:30. Low win
rate, asymmetric payoff, lives or dies by the stop.
